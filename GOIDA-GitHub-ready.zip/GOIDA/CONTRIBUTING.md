# Contributing to GOIDA

Thanks for helping improve GOIDA. It is an early alpha project.

1. Create a branch and keep changes focused.
2. Run `python -m pytest -q` and `python -m compileall -q goida`.
3. Never commit API keys, `.env`, `~/.goida/config.json`, or personal files.
4. Submit a pull request describing the change and how it was tested.

Open an issue first for major features or breaking changes. Keep platform differences (Windows, Linux, Termux) in mind.
