import os

import pytest

from goida import cli


def test_model_alias_management(monkeypatch, tmp_path):
    monkeypatch.setattr(cli, "HOME", tmp_path / ".goida")
    monkeypatch.setattr(cli, "CFG", tmp_path / ".goida" / "config.json")
    inputs = iter(["DeepSeek = example-model", ""])
    monkeypatch.setattr(cli, "prompt", lambda *_args, **_kw: next(inputs))
    c = cli.load()
    cli.models(c)
    assert cli.load()["models"]["DeepSeek"] == "example-model"
    assert cli.load()["active"] == "DeepSeek"


def test_request_requires_configuration():
    with pytest.raises(ValueError, match="Настройте"):
        cli.request({"url": "", "active": "", "models": {}}, [])


def test_config_file_not_world_readable_on_posix(monkeypatch, tmp_path):
    if os.name != "posix":
        pytest.skip("POSIX file permissions only")
    monkeypatch.setattr(cli, "HOME", tmp_path / ".goida")
    monkeypatch.setattr(cli, "CFG", tmp_path / ".goida" / "config.json")
    cli.save({"url": "", "key": "example-not-a-real-key", "models": {}, "active": ""})
    mode = cli.CFG.stat().st_mode & 0o777
    assert mode & 0o077 == 0
