# Changelog

## 0.1.0 — Alpha

- Initial interactive terminal interface with animated GOIDA logo.
- OpenAI-compatible `/chat/completions` support.
- API and model configuration, interactive coding assistant.
- Confirmed file read/write and shell execution, in-memory diff/undo.
- Packaging, tests, CI and open-source documentation.

**Limitations:** No agent sandbox, no session persistence, no automatic support for provider-specific API formats, and no verification on all target platforms yet.
