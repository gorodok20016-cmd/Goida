# Security

GOIDA is experimental software that can **read and edit files** and **execute shell commands** after user confirmation. There is **no sandbox**. AI-generated commands can be destructive even when they appear harmless.

- Run on disposable projects or version-controlled worktrees.
- Review every file diff, command, and access approval before confirming.
- The contents of approved files may be sent to the configured AI provider.
- Never commit `~/.goida/config.json` or provide API keys in prompts.
- Prefer `GOIDA_API_KEY` over storing keys in the local configuration.
- Do not use GOIDA as an unattended system administrator.

If you discover a vulnerability, avoid posting exploit details or credentials in a public issue. Contact the maintainer privately using the repository security reporting mechanism once it is configured.
