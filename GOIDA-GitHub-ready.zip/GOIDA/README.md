# GOIDA — Guidance AI Coding Engine

> **Alpha v0.1.0** · Python 3.9+ · Linux / Termux / Windows · MIT

GOIDA is an open-source, terminal-based AI coding assistant with **bring-your-own-API** support. The command to start it is `goida`. Its animated red terminal logo is inspired by the user's visual direction.

## Features

- Animated startup logo, command completion, colored terminal output.
- OpenAI-compatible `/chat/completions` API and custom model aliases.
- `/settings`, `/api`, `/models`, `/model`, `/status`, `/help`, `/clear`.
- Assistant actions: list files, read files, propose file changes, execute commands **only after confirmation**.
- `/run <command>`, `/plan <task>`, `/diff`, `/undo`, `/quit`.
- Commands run from the directory where GOIDA starts; the assistant's file operations are restricted to that directory.

## Install

Clone this repository or download its source ZIP. Run the commands in the extracted project directory.

### Linux

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install .
goida
```

### Termux

```sh
pkg update && pkg install python
python -m pip install .
goida
```

### Windows PowerShell

```powershell
py -m pip install .
goida
```

On Windows, ensure the Python Scripts directory is on `PATH` if the `goida` command is not found. On Linux, use a virtual environment or `pipx` if your distribution restricts global installs.

## Configure your API

Start `goida`, then enter `/api` to configure a **base URL** such as `https://your-provider.example/v1`. GOIDA appends `/chat/completions` to that URL. Only HTTPS or HTTP on localhost is accepted.

Then enter `/models` and add one alias per line:

```ini
DeepSeek = your-provider-model-id
Fast = another-provider-model-id
```

The right-hand identifiers are **examples only**. Use model IDs supported by your actual provider. `/model` selects the active alias.

You can enter an API key through `/api`, or pass it via the `GOIDA_API_KEY` environment variable instead. The latter is recommended for security. The local configuration is stored in `~/.goida/config.json`; never upload that file.

## Commands

| Command | Description |
| --- | --- |
| `/settings` | Interactive configuration menu |
| `/api` | Configure the API endpoint/key |
| `/models` | Add/remove named models |
| `/model` | Select the model |
| `/run <command>` | Execute a shell command with confirmation |
| `/plan <task>` | Ask for a plan without tools |
| `/diff` | Show changes made in this session |
| `/undo` | Revert the most recent change if still unchanged |
| `/status` | Current API, model, and project directory |
| `/clear` | Clear the in-memory conversation |
| `/quit` | Quit GOIDA |

## Security and limitations

**This is a development alpha, not a safe autonomous sandbox.** Shell commands run with your account permissions. Confirmations alone do not guarantee safety. File content explicitly approved for reading is sent to the configured API provider; review it before approving. Use a disposable Git checkout or worktree. Read [SECURITY.md](SECURITY.md).

The current tool protocol expects AI responses containing JSON objects for tool actions. Provider compatibility varies. Sessions and undo history exist in memory only. Multi-agent support and persistent sessions are planned, not implemented.

## Development

```sh
python -m pip install -e '.[dev]'
python -m pytest -q
python -m compileall -q goida
```

Contributions are welcome; see [CONTRIBUTING.md](CONTRIBUTING.md). Licensed under [MIT](LICENSE).
